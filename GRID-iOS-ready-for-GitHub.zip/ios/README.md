# GRID iOS — Native SwiftUI Milestone 1

Original iPhone app concept for Georgia. This is **source code**, not a tested phone build or a distributable signed `.ipa`.

## Implemented in this source

- Five destinations: Garage, Drive, Rankings, Clubs, Profile, with graphite/lime visual system.
- Add multiple owner-entered cars, optional car photos, selected vehicle.
- GPS start/pause/resume/finish with locally persisted state, trips and GPS points.
- Core Location background-mode declaration and continuous updates initiated in the foreground; actual screen-off, lock, suspension and restart behavior require physical-device testing.
- Distance / drift / accuracy / gap / out-of-order / impossible-jump filtering.
- Live phone-GPS speed (shows unavailable instead of inventing), elapsed time, distance, moving time, moving speed and accuracy.
- Private trip map using built-in Apple MapKit; routes, speed, private maximum and timestamps never publish automatically.
- Opt-in export of local private GPS data; on-device deletion.
- English and partial Georgian UI; recorded timestamp formatting in `Asia/Tbilisi`.
- XCTest unit tests of the GPS filtering helper (not yet run on an iOS simulator).

## Not built in this milestone

- Supabase authentication, synchronization, server leaderboards, anti-cheat server verification, clubs, follows, achievements, photo cloud storage, privacy-zone public sharing, track mode.
- No fake drivers, rank positions, cars, or recorded kilometres are shown.
- App Store and TestFlight require Apple Developer Program membership. Free personal-iPhone testing uses Xcode signing on a Mac **or** a personally signed, GitHub-built IPA installed with AltStore Classic/AltServer on Windows (experimental, not yet tested).

## Free build on a Mac + iPhone

1. Install Xcode on a compatible Mac (from Apple's App Store).
2. Install XcodeGen (`brew install xcodegen`, using Homebrew if available).
3. In Terminal inside this folder, run `xcodegen generate` and open `GRID.xcodeproj`.
4. In Xcode > Signing & Capabilities select your free Apple Account's **Personal Team** and set a unique bundle ID if needed. Use automatic signing.
5. Plug in and unlock your iPhone, choose it as the destination, enable Developer Mode when prompted, and press Run.
6. Before your first test, confirm the app's target has **Background Modes > Location updates** enabled. `UIBackgroundModes=location` is included in Info.plist.
7. Grant **Precise Location** and test a short WALK outdoors before any driving test. Lock your screen for part of it and verify the route and distance.

Apple free personal-device provisioning expires after 7 days and must be renewed through Xcode. Xcode is macOS-only. GitHub macOS Actions can compile a simulator build free on public repositories, but simulator `.app` builds cannot be installed on an iPhone and do not provide signing for a personal device.

## Simplest GitHub setup (Windows-friendly; no Xcode needed to build)

1. From ChatGPT download **`GRID-iOS-ready-for-GitHub.zip`** (the archive has a top-level `ios/` folder). Go to `https://github.com/ratimgg144/GRID`, choose **Add file > Upload files**, upload the **ZIP itself without extraction** to the repository root, and commit.
2. In GitHub choose **Add file > Create new file**. The exact filename must be `.github/workflows/ios.yml` (not `ios.yml` at root). Paste the contents of `ios/ci/ios.yml` from this archive and commit. The GitHub connector currently cannot modify workflow files, so do this one step manually.
3. Open **Actions > GRID iOS checks**. On success download artifact **GRID-iOS-unsigned-IPA**. This is unsigned and requires a free local signing tool such as AltStore Classic + AltServer on Windows before use on an iPhone; see below. This path is *not yet proven to build or install*: share the error log if red.

## GitHub Actions

If uploaded under `ios/` in your existing `ratimgg144/GRID` repository, copy `ci/ios.yml` to the repository's `.github/workflows/ios.yml`. Your connected GitHub app presently lacks workflow-writing permission, so GitHub's web editor is required for this workflow file. The workflow builds for the iOS Simulator without signing, runs tests on an available installed iPhone simulator, and creates a **separate unsigned device IPA** for signing locally with AltStore on Windows. GitHub only builds code; it does not sign apps for your phone.

## No Mac? Free Windows + iPhone route (unverified)

The GitHub Actions workflow also builds `GRID-unsigned.ipa` for an actual iPhone device. This is **not** a signed/installable IPA on its own. GitHub's public-repository standard macOS runners are free.

Once the workflow passes, download the `GRID-iOS-unsigned-IPA` artifact. On Windows, install AltStore Classic via official [AltServer for Windows](https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows), using your **own Apple Account** locally for signing and installation. The official AltStore project says it re-signs sideloaded IPA files with the user's personal certificate. AltServer supports direct `.ipa` sideloading by holding **Shift** while clicking the tray icon. You must trust the developer profile and enable Developer Mode on iOS 16+. Free provisioning normally needs refreshing every 7 days. AltStore is third-party software, not Apple-endorsed; availability and compatibility are not verified for this particular GRID IPA. **Do not send your Apple ID password to ChatGPT, GitHub, or an unknown signing website.**

A simulator `.app` cannot be installed on a physical iPhone. The GitHub device artifact is separately compiled for `iphoneos` and must be signed by AltStore before installation. A PWA is not an equivalent substitute for continuous screen-off GPS recording.

## Security/privacy

Personal trip routes are sensitive location information and remain in on-device Application Support by default. Export data contains precise locations; never share publicly. GPS mock-location indicators and bad fixes are filtered, but phone-only anti-cheat is not tamper-proof. A phone cannot verify which vehicle was used. The app does not reward speed.

## Actual tests performed in this environment

- `swiftc -frontend -parse` passed for `GRID/Models.swift`, `GRID/TripRecorder.swift`, `GRID/GRIDApp.swift`, and `GRIDTests/FixFilterTests.swift` on Linux Swift 6.2 after adding explicit Combine imports.
- Info.plist and project.yml structure checked locally.
- No Xcode, Apple SDK, iOS simulator, or real iPhone was available here. No successful iOS compilation/signing/device test or AltStore install has been claimed.
