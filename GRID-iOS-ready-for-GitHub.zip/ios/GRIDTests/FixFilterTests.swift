import XCTest
@testable import GRID

final class FixFilterTests: XCTestCase {
    private let origin = Date(timeIntervalSince1970: 1_700_000_000)
    private func point(_ latitude: Double, _ longitude: Double, seconds: Double, accuracy: Double = 4) -> RouteFix {
        RouteFix(latitude: latitude, longitude: longitude, accuracy: accuracy,
                 timestamp: origin.addingTimeInterval(seconds), speedMetersPerSecond: nil)
    }
    func testNormalMovement() {
        let a = point(41.7151, 44.8271, seconds: 0)
        let b = point(41.7160, 44.8271, seconds: 12)
        let result = FixFilter.evaluate(previous: a, current: b)
        XCTAssertTrue(result.accepted)
        XCTAssertGreaterThan(result.meters, 80)
        XCTAssertGreaterThan(result.movingSeconds, 0)
    }
    func testStationaryDriftNotAccepted() {
        let a = point(41.7151, 44.8271, seconds: 0)
        let b = point(41.715103, 44.827102, seconds: 8)
        XCTAssertFalse(FixFilter.evaluate(previous: a, current: b).accepted)
    }
    func testImpossibleJumpDiscarded() {
        let a = point(41.7151, 44.8271, seconds: 0)
        let b = point(42.7151, 44.8271, seconds: 1)
        XCTAssertFalse(FixFilter.evaluate(previous: a, current: b).accepted)
    }
    func testOutOfOrderFixDiscarded() {
        let a = point(41.7151, 44.8271, seconds: 10)
        let b = point(41.7161, 44.8271, seconds: 9)
        XCTAssertFalse(FixFilter.evaluate(previous: a, current: b).accepted)
    }
    func testPoorAccuracyDiscarded() {
        let b = point(41.7151, 44.8271, seconds: 0, accuracy: 90)
        XCTAssertFalse(FixFilter.evaluate(previous: nil, current: b).accepted)
    }
    func testLongGapDoesNotAccumulateDistance() {
        let a = point(41.7151, 44.8271, seconds: 0)
        let b = point(41.7161, 44.8271, seconds: 150)
        let result = FixFilter.evaluate(previous: a, current: b)
        XCTAssertTrue(result.accepted)
        XCTAssertEqual(result.meters, 0)
    }
    func testDuplicateLocationDoesNotAddDistance() {
        let a = point(41.7151, 44.8271, seconds: 0)
        let b = point(41.7151, 44.8271, seconds: 10)
        let result = FixFilter.evaluate(previous: a, current: b)
        XCTAssertFalse(result.accepted)
        XCTAssertEqual(result.meters, 0)
    }
    func testInvalidCoordinateRejected() {
        let invalid = point(110.0, 44.8271, seconds: 10)
        XCTAssertFalse(FixFilter.evaluate(previous: nil, current: invalid).accepted)
    }
    func testRegularWindowDoesNotCrossGap() {
        let a = point(41.7151, 44.8271, seconds: 0)
        let b = point(41.7170, 44.8271, seconds: 91)
        let result = FixFilter.evaluate(previous: a, current: b)
        XCTAssertTrue(result.accepted)
        XCTAssertEqual(result.meters, 0)
        XCTAssertEqual(result.movingSeconds, 0)
    }
}
