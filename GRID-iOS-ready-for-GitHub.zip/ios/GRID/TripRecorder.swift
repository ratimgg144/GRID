import Foundation
import Combine
import CoreLocation

@MainActor
final class TripRecorder: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published private(set) var latestSpeedKmh: Double? = nil
    @Published private(set) var lastAccuracyMeters: Double? = nil
    @Published private(set) var warning: String? = nil

    private let manager = CLLocationManager()
    private let store: GridStore
    private var lastCandidateSpeed: Double? = nil

    init(store: GridStore) {
        self.store = store
        super.init()
        manager.delegate = self
        manager.activityType = .automotiveNavigation
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.distanceFilter = 6
        manager.pausesLocationUpdatesAutomatically = false
        if store.active?.recording == true { startLocationManager() }
    }

    var authorization: CLAuthorizationStatus { manager.authorizationStatus }
    var isPaused: Bool { store.active?.pausedAt != nil }

    func start(vehicleID: UUID) {
        guard store.active == nil else { return }
        store.setActive(ActiveJourney(vehicleID: vehicleID))
        latestSpeedKmh = nil
        warning = nil
        startLocationManager()
    }

    func pause() {
        guard var trip = store.active, trip.recording else { return }
        trip.recording = false
        trip.pausedAt = Date()
        store.setActive(trip)
        manager.stopUpdatingLocation()
        manager.allowsBackgroundLocationUpdates = false
        latestSpeedKmh = nil
    }

    func resume() {
        guard var trip = store.active, let paused = trip.pausedAt else { return }
        trip.pausedSeconds += Date().timeIntervalSince(paused)
        trip.pausedAt = nil
        trip.recording = true
        trip.legStartedAt = Date()
        store.setActive(trip)
        latestSpeedKmh = nil
        // Break the leg explicitly: the first fix after resuming must not bridge the pause.
        lastCandidateSpeed = nil
        startLocationManager()
    }

    func finish() {
        guard let trip = store.active else { return }
        let end = Date()
        let finished = Journey(id: trip.id, vehicleID: trip.vehicleID, startedAt: trip.startedAt,
                               endedAt: end, distanceMeters: trip.distanceMeters,
                               movingSeconds: trip.movingSeconds, elapsedSeconds: trip.elapsed(at: end),
                               privateMaxSpeedKmh: trip.privateMaxSpeedKmh, route: trip.route)
        manager.stopUpdatingLocation()
        manager.allowsBackgroundLocationUpdates = false
        latestSpeedKmh = nil
        store.add(finished)
    }

    private func startLocationManager() {
        switch manager.authorizationStatus {
        case .notDetermined:
            warning = "Allow precise location to record journeys"
            manager.requestWhenInUseAuthorization()
        case .authorizedWhenInUse, .authorizedAlways:
            guard store.active?.recording == true else { return }
            // Requires UIBackgroundModes=location in Info.plist.
            manager.allowsBackgroundLocationUpdates = true
            manager.showsBackgroundLocationIndicator = true
            manager.startUpdatingLocation()
            warning = manager.accuracyAuthorization == .reducedAccuracy ? "Precise location is off" : nil
        case .denied, .restricted:
            warning = "Enable Location in iPhone Settings to record trips"
        @unknown default:
            warning = "Location permission unavailable"
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        startLocationManager()
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        warning = "GPS unavailable: \(error.localizedDescription)"
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard var trip = store.active, trip.recording, trip.pausedAt == nil else { return }
        for fix in locations {
            if #available(iOS 15.0, *), fix.sourceInformation?.isSimulatedBySoftware == true { continue }
            guard fix.timestamp <= Date().addingTimeInterval(5),
                  fix.timestamp >= trip.startedAt.addingTimeInterval(-5) else { continue }
            let rawSpeed = fix.speed >= 0 && fix.speedAccuracy >= 0 && fix.speedAccuracy <= 3 ? fix.speed : nil
            let point = RouteFix(latitude: fix.coordinate.latitude, longitude: fix.coordinate.longitude,
                                 accuracy: fix.horizontalAccuracy, timestamp: fix.timestamp,
                                 speedMetersPerSecond: rawSpeed)
            if (0...45).contains(fix.horizontalAccuracy) {
                lastAccuracyMeters = fix.horizontalAccuracy
                latestSpeedKmh = rawSpeed.map { $0 * 3.6 }
            } else {
                latestSpeedKmh = nil
            }
            let previous = trip.route.last
            let result = FixFilter.evaluate(previous: previous, current: point)
            if !result.accepted { continue }
            // After a pause or huge gap, never add distance across the discontinuity.
            let crossesPause = previous.map { $0.timestamp < trip.legStartedAt } ?? false
            let increment = crossesPause ? 0 : result.meters
            trip.distanceMeters += increment
            trip.movingSeconds += result.movingSeconds
            trip.route.append(point)
            if let rawSpeed, rawSpeed <= 65, let previousSpeed = lastCandidateSpeed,
               abs(previousSpeed - rawSpeed) < 7.5 {
                let kmh = rawSpeed * 3.6
                trip.privateMaxSpeedKmh = max(trip.privateMaxSpeedKmh ?? 0, kmh)
            }
            lastCandidateSpeed = rawSpeed
        }
        // Atomic local save after accepted batch, including background fixes.
        store.setActive(trip)
    }
}
