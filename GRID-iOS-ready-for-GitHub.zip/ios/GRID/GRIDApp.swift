import SwiftUI
import Combine
import PhotosUI
import MapKit
import UIKit
import UniformTypeIdentifiers

private enum Palette {
    static let background = Color(red: 0.067, green: 0.078, blue: 0.074)
    static let surface = Color(red: 0.115, green: 0.133, blue: 0.125)
    static let line = Color(red: 0.20, green: 0.24, blue: 0.22)
    static let lime = Color(red: 0.80, green: 0.98, blue: 0.41)
    static let muted = Color(red: 0.59, green: 0.64, blue: 0.60)
}

@main
struct GRIDApp: App {
    @StateObject private var store: GridStore
    @StateObject private var recorder: TripRecorder
    init() {
        let store = GridStore()
        _store = StateObject(wrappedValue: store)
        _recorder = StateObject(wrappedValue: TripRecorder(store: store))
    }
    var body: some Scene {
        WindowGroup {
            GridShell()
                .environmentObject(store)
                .environmentObject(recorder)
                .preferredColorScheme(.dark)
                .tint(Palette.lime)
        }
    }
}

private enum SectionTab: String, CaseIterable {
    case garage = "Garage", drive = "Drive", rankings = "Rankings", clubs = "Clubs", profile = "Profile"
    var icon: String { switch self {
        case .garage: return "car.side.fill"
        case .drive: return "steeringwheel"
        case .rankings: return "chart.bar.xaxis"
        case .clubs: return "person.3"
        case .profile: return "person.crop.circle"
    } }
    func label(_ ka: Bool) -> String { switch self {
        case .garage: return ka ? "გარაჟი" : "Garage"
        case .drive: return ka ? "გზა" : "Drive"
        case .rankings: return ka ? "რეიტინგი" : "Rankings"
        case .clubs: return ka ? "კლუბები" : "Clubs"
        case .profile: return ka ? "პროფილი" : "Profile"
    } }
}

private struct GridShell: View {
    @EnvironmentObject var store: GridStore
    @AppStorage("grid.georgian") var ka = false
    @State private var selection = SectionTab.garage
    var body: some View {
        TabView(selection: $selection) {
            GarageScreen(ka: ka).tabItem { Label(SectionTab.garage.label(ka), systemImage: SectionTab.garage.icon) }.tag(SectionTab.garage)
            DriveScreen(ka: ka).tabItem { Label(SectionTab.drive.label(ka), systemImage: SectionTab.drive.icon) }.tag(SectionTab.drive)
            RankingsScreen(ka: ka).tabItem { Label(SectionTab.rankings.label(ka), systemImage: SectionTab.rankings.icon) }.tag(SectionTab.rankings)
            ClubsScreen(ka: ka).tabItem { Label(SectionTab.clubs.label(ka), systemImage: SectionTab.clubs.icon) }.tag(SectionTab.clubs)
            ProfileScreen(ka: ka).tabItem { Label(SectionTab.profile.label(ka), systemImage: SectionTab.profile.icon) }.tag(SectionTab.profile)
        }
        .background(Palette.background)
        .toolbarBackground(Palette.background, for: .tabBar)
        .toolbarBackground(.visible, for: .tabBar)
    }
}

private func unitDistance(_ meters: Double) -> String { String(format: "%.2f", meters / 1000) }
private func elapsedText(_ seconds: TimeInterval) -> String {
    let number = max(0, Int(seconds))
    return String(format: "%02d:%02d:%02d", number / 3600, number / 60 % 60, number % 60)
}
private func dateText(_ date: Date) -> String {
    let f = DateFormatter(); f.dateStyle = .medium; f.timeStyle = .short
    f.timeZone = TimeZone(identifier: "Asia/Tbilisi")
    return f.string(from: date)
}

private struct Eyebrow: View {
    let text: String
    var body: some View { Text(text.uppercased()).font(.system(size: 10, weight: .bold, design: .rounded))
        .tracking(3).foregroundStyle(Palette.lime) }
}
private struct Metric: View {
    let value: String; let label: String
    var body: some View { VStack(alignment: .leading, spacing: 7) {
        Text(value).font(.system(size: 27, weight: .medium, design: .rounded)).monospacedDigit()
        Text(label).font(.system(size: 11)).foregroundStyle(Palette.muted)
    }.frame(maxWidth: .infinity, alignment: .leading) }
}
private struct MainButton: View {
    let title: String; let disabled: Bool; let action: () -> Void
    init(_ title: String, disabled: Bool = false, action: @escaping () -> Void) {
        self.title = title; self.disabled = disabled; self.action = action
    }
    var body: some View {
        Button(action: action) { Text(title).tracking(0.7).font(.system(size: 14, weight: .bold))
            .frame(maxWidth: .infinity).frame(height: 54) }
        .buttonStyle(.plain).background(disabled ? Palette.muted : Palette.lime, in: RoundedRectangle(cornerRadius: 12))
        .foregroundStyle(Palette.background).disabled(disabled)
    }
}
private struct ScreenHeader: View {
    let eyebrow: String; let title: String
    var body: some View { VStack(alignment: .leading, spacing: 8) {
        HStack { Text("▦").foregroundStyle(Palette.lime).font(.title3.weight(.heavy))
            Text("GRID").tracking(3).font(.system(size: 18, weight: .black))
            Spacer(); Text("GEORGIA / 01").tracking(1.5).font(.system(size: 9)).foregroundStyle(Palette.muted) }
            .padding(.bottom, 27)
        Eyebrow(text: eyebrow)
        Text(title).font(.system(size: 30, weight: .semibold, design: .rounded))
    } }
}

private struct VehicleImage: View {
    @EnvironmentObject var store: GridStore
    let photo: String?
    var body: some View {
        ZStack {
            Palette.surface
            if let url = store.photoURL(photo), let image = UIImage(contentsOfFile: url.path) {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                VStack(spacing: 13) {
                    Image(systemName: "car.side.fill").font(.system(size: 65)).foregroundStyle(Palette.muted)
                    Text("ADD YOUR CAR PHOTO").tracking(2).font(.system(size: 9)).foregroundStyle(Palette.muted)
                }
            }
        }.frame(maxWidth: .infinity).frame(height: 220).clipped().clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

private struct GarageScreen: View {
    @EnvironmentObject var store: GridStore
    let ka: Bool
    @State private var adding = false
    @State private var selectedJourney: Journey?
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 23) {
            HStack(alignment: .bottom) {
                ScreenHeader(eyebrow: ka ? "შენი კოლექცია" : "YOUR COLLECTION", title: ka ? "გარაჟი" : "The garage")
                Spacer(); Button { adding = true } label: { Image(systemName: "plus").font(.title2) }
            }
            if let vehicle = store.selectedVehicle {
                VehicleImage(photo: vehicle.photoName)
                VStack(alignment: .leading, spacing: 5) {
                    Text(vehicle.nickname).font(.system(size: 28, weight: .semibold))
                    Text("\(vehicle.year)   \(vehicle.make) \(vehicle.model)   \(vehicle.trim)").font(.subheadline).foregroundStyle(Palette.muted)
                }
                HStack {
                    Metric(value: unitDistance(store.journeys.filter { $0.vehicleID == vehicle.id }.reduce(0) { $0 + $1.distanceMeters }) + " km", label: ka ? "ჩაწერილი GRID-ში" : "Recorded in GRID")
                    Metric(value: "\(store.journeys.filter { $0.vehicleID == vehicle.id }.count)", label: ka ? "მგზავრობები" : "Journeys")
                }
                Divider().overlay(Palette.line)
                Eyebrow(text: ka ? "აირჩიე მანქანა" : "SELECT A VEHICLE")
                ScrollView(.horizontal) { HStack(spacing: 9) {
                    ForEach(store.vehicles) { car in
                        Button { store.select(car.id) } label: {
                            Text(car.nickname).font(.caption.weight(.medium))
                                .padding(.horizontal, 15).padding(.vertical, 10)
                                .background(car.id == vehicle.id ? Palette.lime : Palette.surface, in: Capsule())
                                .foregroundStyle(car.id == vehicle.id ? Palette.background : .white)
                        }.buttonStyle(.plain)
                    }
                }}.scrollIndicators(.hidden)
            } else {
                VehicleImage(photo: nil)
                Text(ka ? "დაამატე პირველი ავტომობილი" : "Your garage starts here.").font(.title3.weight(.semibold))
                Text(ka ? "მანქანის მონაცემებს თავად ავსებ. GPS მათ ვერ ადასტურებს." : "Add a real car. Vehicle details are owner-entered; GPS cannot verify identity.")
                    .font(.subheadline).foregroundStyle(Palette.muted)
                MainButton(ka ? "მანქანის დამატება" : "ADD YOUR FIRST CAR") { adding = true }
            }
            Divider().overlay(Palette.line)
            HStack { Text(ka ? "მგზავრობების ისტორია" : "Journey log").font(.title2.weight(.semibold))
                Spacer(); Text("\(store.journeys.count)").foregroundStyle(Palette.muted) }
            let matching = store.journeys.filter { store.selectedVehicle == nil || $0.vehicleID == store.selectedVehicle?.id }
            ForEach(matching) { trip in
                Button { selectedJourney = trip } label: {
                    HStack(spacing: 10) {
                        VStack(alignment: .leading, spacing: 5) {
                            Text(dateText(trip.startedAt)).font(.subheadline)
                            Text(ka ? "პირადი · მოწყობილობაზე" : "Private · On device").font(.caption2).foregroundStyle(Palette.muted)
                        }
                        Spacer(); Text(unitDistance(trip.distanceMeters) + " km").font(.headline).foregroundStyle(Palette.lime)
                        Image(systemName: "chevron.right").foregroundStyle(Palette.muted)
                    }.padding(.vertical, 5)
                }.buttonStyle(.plain)
                Divider().overlay(Palette.line)
            }
            if matching.isEmpty { Text(ka ? "მგზავრობები ჯერ არ გაქვს." : "No recorded journeys yet.").font(.subheadline).foregroundStyle(Palette.muted) }
        }.padding(25).frame(maxWidth: .infinity, alignment: .leading) }
        .background(Palette.background)
        .sheet(isPresented: $adding) { AddVehicleSheet(ka: ka) }
        .sheet(item: $selectedJourney) { JourneyDetail(trip: $0, ka: ka) }
    }
}

private struct AddVehicleSheet: View {
    @EnvironmentObject var store: GridStore
    @Environment(\.dismiss) var dismiss
    let ka: Bool
    @State private var nickname = ""
    @State private var make = ""
    @State private var model = ""
    @State private var year = String(Calendar.current.component(.year, from: Date()))
    @State private var trim = ""
    @State private var fuel = ""
    @State private var modifications = ""
    @State private var photo: PhotosPickerItem?
    @State private var photoName: String?
    @State private var photoError: String?
    var body: some View {
        NavigationStack {
            Form {
                Section("Vehicle") {
                    TextField("Nickname", text: $nickname)
                    TextField("Make", text: $make)
                    TextField("Model", text: $model)
                    TextField("Year", text: $year).keyboardType(.numberPad)
                    TextField("Trim", text: $trim)
                    TextField("Fuel", text: $fuel)
                    TextField("Modifications (optional)", text: $modifications)
                }
                Section("Photo") {
                    PhotosPicker(selection: $photo, matching: .images) { Label(photoName == nil ? "Select car photo" : "Photo selected", systemImage: "photo") }
                    if let photoError { Text(photoError).foregroundStyle(.red).font(.caption) }
                }
                Section { Text("Vehicle specifications are owner-entered. A phone cannot verify car identity.").font(.caption).foregroundStyle(Palette.muted) }
            }
            .navigationTitle(ka ? "მანქანის დამატება" : "Add a car")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        guard let year = Int(year) else { return }
                        store.add(Vehicle(nickname: nickname.trimmingCharacters(in: .whitespaces), make: make.trimmingCharacters(in: .whitespaces),
                                          model: model.trimmingCharacters(in: .whitespaces), year: year,
                                          trim: trim, fuel: fuel, modifications: modifications, photoName: photoName))
                        dismiss()
                    }.disabled(nickname.trimmingCharacters(in: .whitespaces).isEmpty || make.isEmpty || model.isEmpty || !(1886...2100).contains(Int(year) ?? 0))
                }
            }
            .onChange(of: photo) { _, new in
                Task { @MainActor in
                    guard let bytes = try? await new?.loadTransferable(type: Data.self),
                          let image = UIImage(data: bytes), let jpeg = image.jpegData(compressionQuality: 0.82) else { return }
                    do { photoName = try store.importCarPhoto(jpeg); photoError = nil }
                    catch { photoError = error.localizedDescription }
                }
            }
        }.preferredColorScheme(.dark)
    }
}

private struct DriveScreen: View {
    @EnvironmentObject var store: GridStore
    @EnvironmentObject var recorder: TripRecorder
    let ka: Bool
    @State private var tick = Date()
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 27) {
            ScreenHeader(eyebrow: ka ? "GPS მონაცემები" : "LIVE INSTRUMENTS", title: ka ? "მგზავრობა" : "Drive")
            HStack(spacing: 9) {
                Circle().fill(store.active?.recording == true ? Palette.lime : Palette.muted).frame(width: 7, height: 7)
                Text(store.active == nil ? "READY" : store.active?.recording == true ? "RECORDING" : "PAUSED")
                    .tracking(2).font(.system(size: 11)).foregroundStyle(Palette.muted)
            }.padding(.top, 13)
            HStack(alignment: .lastTextBaseline, spacing: 12) {
                Text(recorder.latestSpeedKmh.map { "\(Int($0))" } ?? "—")
                    .font(.system(size: 112, weight: .ultraLight, design: .rounded)).monospacedDigit().minimumScaleFactor(0.7)
                Text("km/h").font(.body).foregroundStyle(Palette.muted)
            }.frame(maxWidth: .infinity, alignment: .leading)
            Text(ka ? "ტელეფონის GPS · არა OBD" : "Phone GPS · not OBD").font(.caption).foregroundStyle(Palette.muted)
            Divider().overlay(Palette.line)
            HStack(spacing: 18) {
                Metric(value: unitDistance(store.active?.distanceMeters ?? 0) + " km", label: ka ? "ჩაწერილი მანძილი" : "Recorded distance")
                Metric(value: elapsedText(store.active?.elapsed(at: tick) ?? 0), label: ka ? "გასული დრო" : "Elapsed")
            }
            HStack(spacing: 18) {
                Metric(value: elapsedText(store.active?.movingSeconds ?? 0), label: ka ? "მოძრაობის დრო" : "Moving time")
                Metric(value: recorder.lastAccuracyMeters.map { String(format: "±%.0f m", $0) } ?? "—", label: ka ? "GPS სიზუსტე" : "GPS accuracy")
            }
            HStack(spacing: 18) {
                Metric(value: (store.active?.movingSeconds ?? 0) >= 1
                       ? String(format: "%.1f km/h", (store.active!.distanceMeters / store.active!.movingSeconds) * 3.6)
                       : "—", label: ka ? "საშუალო სიჩქარე" : "Average moving speed")
                Spacer().frame(maxWidth: .infinity)
            }
            Divider().overlay(Palette.line)
            Text(store.selectedVehicle.map { "\($0.nickname)  ·  \($0.make) \($0.model)" } ?? (ka ? "აირჩიე მანქანა გარაჟში" : "Select a car in Garage"))
                .font(.subheadline).foregroundStyle(Palette.muted)
            if store.active == nil {
                MainButton(ka ? "მგზავრობის დაწყება" : "START JOURNEY", disabled: store.selectedVehicle == nil) {
                    if let id = store.selectedVehicle?.id { recorder.start(vehicleID: id) }
                }
            } else {
                HStack(spacing: 10) {
                    Button(store.active?.recording == true ? (ka ? "შეჩერება" : "PAUSE") : (ka ? "გაგრძელება" : "RESUME")) {
                        store.active?.recording == true ? recorder.pause() : recorder.resume()
                    }.buttonStyle(.bordered).frame(maxWidth: .infinity)
                    MainButton(ka ? "დასრულება" : "FINISH") { recorder.finish() }
                }
            }
            if let warning = recorder.warning { Label(warning, systemImage: "location.slash").font(.caption).foregroundStyle(.orange) }
            if let error = store.lastSaveError { Text(error).font(.caption).foregroundStyle(.red) }
            Text(ka ? "ეკრანის გამორთვისას GPS ჩაწერის გაგრძელება მხარდაჭერილია, მაგრამ ტელეფონზე უნდა შემოწმდეს. მართვისას არ შეეხოთ ტელეფონს." :
                "Designed for screen-off GPS recording; physical-device verification is still required. Trips are private. Never operate your phone while driving.")
                .font(.caption).foregroundStyle(Palette.muted).lineSpacing(4)
        }.padding(25).frame(maxWidth: .infinity, alignment: .leading) }
        .background(Palette.background)
        .task { for await date in Timer.publish(every: 1, on: .main, in: .common).autoconnect().values { tick = date } }
    }
}

private struct JourneyDetail: View {
    @EnvironmentObject var store: GridStore
    @Environment(\.dismiss) var dismiss
    let trip: Journey
    let ka: Bool
    @State private var deleting = false
    var body: some View {
        NavigationStack {
            ScrollView { VStack(alignment: .leading, spacing: 22) {
                Eyebrow(text: ka ? "ჩაწერილი მოგზაურობა" : "RECORDED JOURNEY")
                Text(dateText(trip.startedAt)).font(.title2.weight(.semibold))
                if trip.route.count > 1 {
                    Map(initialPosition: .automatic) {
                        MapPolyline(coordinates: trip.route.map(\.coordinate)).stroke(Palette.lime, lineWidth: 4)
                    }.frame(height: 260).clipShape(RoundedRectangle(cornerRadius: 15))
                } else {
                    ContentUnavailableView("Route unavailable", systemImage: "map", description: Text("Not enough reliable GPS fixes for a route."))
                }
                Text("Map data © Apple. Route and location are private on this device.").font(.caption2).foregroundStyle(Palette.muted)
                HStack { Metric(value: unitDistance(trip.distanceMeters) + " km", label: "Recorded in GRID")
                    Metric(value: elapsedText(trip.elapsedSeconds), label: "Elapsed") }
                HStack { Metric(value: elapsedText(trip.movingSeconds), label: "Moving time")
                    Metric(value: trip.privateMaxSpeedKmh.map { String(format: "%.0f km/h", $0) } ?? "—", label: "Private GPS max") }
                Divider().overlay(Palette.line)
                Text("Speeds are phone GPS measurements, not vehicle/OBD telemetry. GPS cannot verify vehicle identity. No data is shared automatically.")
                    .font(.caption).foregroundStyle(Palette.muted)
                Button(role: .destructive) { deleting = true } label: { Label("Delete this journey", systemImage: "trash") }
            }.padding(24) }
            .background(Palette.background)
            .navigationTitle("Journey").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Close") { dismiss() } } }
            .confirmationDialog("Permanently delete this local journey?", isPresented: $deleting) {
                Button("Delete", role: .destructive) { store.deleteJourney(trip.id); dismiss() }
            }
        }.preferredColorScheme(.dark)
    }
}

private struct RankingsScreen: View {
    let ka: Bool
    var body: some View { PlaceholderScreen(eyebrow: "COMMUNITY DISTANCE", title: ka ? "რეიტინგი" : "Rankings", icon: "chart.bar.xaxis",
        heading: ka ? "ონლაინ რეიტინგი ჯერ მიუწვდომელია" : "Backend not connected",
        detail: "There are no fabricated drivers, kilometres or positions. Weekly and monthly rankings will activate only after server validation and user opt-in.") }
}
private struct ClubsScreen: View {
    let ka: Bool
    var body: some View { PlaceholderScreen(eyebrow: "COMMUNITY", title: ka ? "კლუბები" : "Clubs", icon: "person.3",
        heading: "Coming after verified trip sync",
        detail: "Club creation, membership and shared recorded-distance challenges are not yet available in the iOS milestone.") }
}
private struct PlaceholderScreen: View {
    let eyebrow: String; let title: String; let icon: String; let heading: String; let detail: String
    var body: some View { VStack(alignment: .leading, spacing: 23) {
        ScreenHeader(eyebrow: eyebrow, title: title)
        Spacer().frame(height: 60)
        Image(systemName: icon).font(.system(size: 65)).foregroundStyle(Palette.muted)
        Text(heading).font(.title2.weight(.semibold))
        Text(detail).font(.subheadline).foregroundStyle(Palette.muted).fixedSize(horizontal: false, vertical: true)
        Spacer()
    }.frame(maxWidth: .infinity, alignment: .leading).padding(25).background(Palette.background) }
}
private struct ProfileScreen: View {
    @EnvironmentObject var store: GridStore
    @AppStorage("grid.georgian") private var ka = false
    @State private var eraseConfirmation = false
    @State private var exportDocument: GridJSONFile?
    @State private var isExporting = false
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 25) {
            ScreenHeader(eyebrow: ka ? "ანგარიში და კონფიდენციალურობა" : "ACCOUNT & PRIVACY", title: ka ? "პროფილი" : "Your cockpit")
            HStack { Metric(value: "\(store.journeys.count)", label: "Trips saved")
                Metric(value: unitDistance(store.allTimeMeters) + " km", label: "Recorded in GRID") }
            Divider().overlay(Palette.line)
            Toggle("ქართული", isOn: $ka)
            Divider().overlay(Palette.line)
            Eyebrow(text: "PRIVACY BY DESIGN")
            Text("No live location is published. Exact routes stay on this device. GRID does not claim to know your car's actual lifetime mileage.")
                .font(.subheadline).foregroundStyle(Palette.muted)
            Text("Social sign-in, backend sync and account deletion are not configured in this iOS milestone.")
                .font(.caption).foregroundStyle(Palette.muted)
            Button {
                if let bytes = try? store.exportedData() {
                    exportDocument = GridJSONFile(bytes: bytes)
                    isExporting = true
                }
            } label: {
                Label("Export private data (JSON)", systemImage: "square.and.arrow.up")
                    .frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 12)
            }
            Button(role: .destructive) { eraseConfirmation = true } label: {
                Label("Erase all local garage and trips", systemImage: "trash")
            }.disabled(store.active != nil)
            Text("GRID iOS 0.1 · Local-first / no backend").font(.caption2).foregroundStyle(Palette.muted)
        }.padding(25).frame(maxWidth: .infinity, alignment: .leading) }
        .background(Palette.background)
        .fileExporter(isPresented: $isExporting, document: exportDocument, contentType: .json, defaultFilename: "GRID-private-export") { _ in }
        .confirmationDialog("Erase all on-device GRID records? This cannot be undone.", isPresented: $eraseConfirmation) {
            Button("Erase all", role: .destructive) { store.eraseEverything() }
        }
    }
 }

private struct GridJSONFile: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var bytes: Data
    init(bytes: Data) { self.bytes = bytes }
    init(configuration: ReadConfiguration) throws {
        bytes = configuration.file.regularFileContents ?? Data()
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: bytes)
    }
}
