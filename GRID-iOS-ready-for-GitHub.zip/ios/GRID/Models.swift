import Foundation
import Combine
import CoreLocation

struct Vehicle: Codable, Identifiable, Equatable {
    var id: UUID = UUID()
    var nickname: String
    var make: String
    var model: String
    var year: Int
    var trim: String
    var fuel: String
    var modifications: String
    var photoName: String? = nil
}

struct RouteFix: Codable, Identifiable {
    var id: UUID = UUID()
    var latitude: Double
    var longitude: Double
    var accuracy: Double
    var timestamp: Date
    var speedMetersPerSecond: Double?

    var coordinate: CLLocationCoordinate2D { .init(latitude: latitude, longitude: longitude) }
}

struct Journey: Codable, Identifiable {
    var id: UUID = UUID()
    var vehicleID: UUID
    var startedAt: Date
    var endedAt: Date
    var distanceMeters: Double
    var movingSeconds: TimeInterval
    var elapsedSeconds: TimeInterval
    var privateMaxSpeedKmh: Double?
    var route: [RouteFix]
}

struct ActiveJourney: Codable {
    var id: UUID = UUID()
    var vehicleID: UUID
    var startedAt: Date = Date()
    var pausedAt: Date? = nil
    var pausedSeconds: TimeInterval = 0
    var distanceMeters: Double = 0
    var movingSeconds: TimeInterval = 0
    var privateMaxSpeedKmh: Double? = nil
    var route: [RouteFix] = []
    var recording: Bool = true
    var legStartedAt: Date = Date()

    func elapsed(at date: Date = Date()) -> TimeInterval {
        let currentPause = pausedAt.map { date.timeIntervalSince($0) } ?? 0
        return max(0, date.timeIntervalSince(startedAt) - pausedSeconds - currentPause)
    }
}

struct GridDisk: Codable {
    var vehicles: [Vehicle] = []
    var journeys: [Journey] = []
    var activeJourney: ActiveJourney? = nil
    var selectedVehicleID: UUID? = nil
}

@MainActor
final class GridStore: ObservableObject {
    @Published private(set) var disk: GridDisk = .init()
    @Published var lastSaveError: String? = nil

    private let root: URL
    private let dataFile: URL

    init() {
        let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        root = support.appendingPathComponent("GRID", isDirectory: true)
        dataFile = root.appendingPathComponent("local-data.json")
        do {
            try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: dataFile.path) {
                disk = try JSONDecoder().decode(GridDisk.self, from: Data(contentsOf: dataFile))
            }
        } catch { lastSaveError = "Could not read local records: \(error.localizedDescription)" }
    }

    var vehicles: [Vehicle] { disk.vehicles }
    var journeys: [Journey] { disk.journeys.sorted { $0.startedAt > $1.startedAt } }
    var active: ActiveJourney? { disk.activeJourney }
    var selectedVehicle: Vehicle? {
        disk.vehicles.first { $0.id == disk.selectedVehicleID } ?? disk.vehicles.first
    }
    var allTimeMeters: Double { disk.journeys.reduce(0) { $0 + $1.distanceMeters } }

    func add(_ car: Vehicle) {
        disk.vehicles.append(car)
        disk.selectedVehicleID = car.id
        persist()
    }

    func select(_ id: UUID) { disk.selectedVehicleID = id; persist() }
    func setActive(_ value: ActiveJourney?) { disk.activeJourney = value; persist() }
    func add(_ trip: Journey) { disk.journeys.append(trip); disk.activeJourney = nil; persist() }
    func deleteJourney(_ id: UUID) { disk.journeys.removeAll { $0.id == id }; persist() }

    func eraseEverything() {
        disk = .init()
        try? FileManager.default.removeItem(at: root.appendingPathComponent("photos"))
        persist()
    }

    func importCarPhoto(_ bytes: Data) throws -> String {
        let folder = root.appendingPathComponent("photos", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let name = UUID().uuidString + ".jpg"
        try bytes.write(to: folder.appendingPathComponent(name), options: .atomic)
        return name
    }

    func photoURL(_ name: String?) -> URL? {
        guard let name else { return nil }
        return root.appendingPathComponent("photos").appendingPathComponent(name)
    }

    func exportedData() throws -> Data { try JSONEncoder().encode(disk) }

    private func persist() {
        do {
            try JSONEncoder().encode(disk).write(to: dataFile, options: .atomic)
            lastSaveError = nil
        } catch { lastSaveError = "Save failed: \(error.localizedDescription)" }
    }
}

/** Pure, independently testable distance quality gate. No fabricated readings. */
enum FixFilter {
    static func evaluate(previous: RouteFix?, current: RouteFix) -> (accepted: Bool, meters: Double, movingSeconds: Double) {
        guard current.latitude.isFinite, current.longitude.isFinite,
              (-90...90).contains(current.latitude), (-180...180).contains(current.longitude),
              current.accuracy.isFinite, (0...45).contains(current.accuracy) else { return (false, 0, 0) }
        guard let previous else { return (true, 0, 0) }
        let seconds = current.timestamp.timeIntervalSince(previous.timestamp)
        guard seconds > 0 else { return (false, 0, 0) }
        let old = CLLocation(latitude: previous.latitude, longitude: previous.longitude)
        let new = CLLocation(latitude: current.latitude, longitude: current.longitude)
        let meters = old.distance(from: new)
        // A >90s sampling gap may reflect a pause or suspension: retain point but never bridge the gap.
        guard seconds <= 90 else { return (true, 0, 0) }
        let minimumMovement = max(8.0, 0.35 * (previous.accuracy + current.accuracy))
        guard meters >= minimumMovement else { return (false, 0, 0) }
        // Exclude impossible jumps. No public speed contests are created from GPS readings.
        guard (meters / seconds) <= 65 else { return (false, 0, 0) }
        return (true, meters, (meters / seconds) > 1.1 ? min(seconds, 30) : 0)
    }
}
